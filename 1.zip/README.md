Ali Taheri's homepage
